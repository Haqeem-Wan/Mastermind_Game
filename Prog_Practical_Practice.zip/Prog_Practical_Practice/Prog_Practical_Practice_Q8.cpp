/*

Convert the flowchart (flowch-a.pdf) into a C++ program.

Sample Run 1:
=============
Enter an integer: 71
10201

Sample Run 2:
=============
Enter an integer: 80
49

Sample Run 3:
=============
Enter an integer: 110
81

*/

#include <iostream>
# include <string>
using namespace std;

int main()
{
    //
    // Write your program here
    //

    return 0;
}