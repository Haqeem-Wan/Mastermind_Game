/*

Write the needed code to make the program runs correctly.

Prompt the user to input four integers between 0 and 20
and then output the following horizontal histogram.
Each asterisk should represent one mark.

The sample runs are as follows.


Sample Run 1:

    Input four integers between 0 and 20 => 10 12 18 8

    mark 1: **********
    mark 2: ************
    mark 3: ******************
    mark 4: ********


Sample Run 2:

    Input four integers betweem 0 and 20 => 19 9 11 6

    mark 1: *******************
    mark 2: *********
    mark 3: ***********
    mark 4: ******

*/ 

#include <iostream>
using namespace std;

int main()
{
    // Write your code below



    return 0;
}